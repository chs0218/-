#include <gl/glew.h>
#include <gl/freeglut.h>
#include <gl/freeglut_ext.h>
#include <glm/glm.hpp>
#include <glm/ext.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <fstream>

#define BOXSIZE 0.5

void make_vertexShaders();
void make_fragmentShaders();
void InitShader();
GLvoid InitBuffer();
GLvoid Reshape(int w, int h);
char* filetobuf(const char* file);

GLchar* vertexsource;
GLchar* fragmentsource;
GLuint vertexShader[2], fragmentShader[5];
GLuint s_program[6];
GLuint vao[2], vbo[3], EBO[3];
GLint width, height;

bool RotateA = false, RotateR = false, RotateY = false, MovePlusZ = false, MoveMinusZ = false, RotateCranePlus = false, RotateCraneMinus = false, RotateArm = false, ArmPlus = true;
bool RotateOnlyFront = false, RotateOnlyTop = false;
GLfloat topR = 0.0;
GLfloat RotateCenterY = 0.0, cameraX = 0.0, cameraY = 3.0, cameraZ = 4.0, frontcameraX = 0.0, frontcameraZ = 1.0, topcameraX = 0.0, topcameraZ = 0.0, cameraR = 0.0, craneZ = 0.0, cranebodyR = 0.0, armR = 0.0, RotateCenter = 0.0;
GLfloat CameraDirX = 0.0, CameraDirY = 0.0, CameraDirZ = 0.0;
GLfloat frontCameraDirX = 0.0, frontCameraDirZ = 0.0;
GLfloat topCameraDirX = 0.0, topCameraDirZ = 0.0;


glm::vec3 topcameraPos = glm::vec3(topcameraX, 2.0, topcameraZ); //--- ī�޶� ��ġ
glm::vec3 topcameraDirection = glm::vec3(topCameraDirX, 0.0, topCameraDirZ); //--- ī�޶� �ٶ󺸴� ����
glm::vec3 topcameraUp = glm::vec3(1.0 * glm::sin(glm::radians(cameraR)), 0.0f, 1.0 * glm::cos(glm::radians(cameraR))); //--- ī�޶� ���� ����

glm::vec3 frontcameraPos = glm::vec3(frontcameraX, 0.0, frontcameraZ); //--- ī�޶� ��ġ
glm::vec3 frontcameraDirection = glm::vec3(frontCameraDirX, 0.0, frontCameraDirZ); //--- ī�޶� �ٶ󺸴� ����
glm::vec3 frontcameraUp = glm::vec3(0.0f, 1.0f, 0.0f); //--- ī�޶� ���� ����

glm::vec3 cameraPos = glm::vec3(cameraX, cameraY, cameraZ); //--- ī�޶� ��ġ
glm::vec3 cameraDirection = glm::vec3(CameraDirX, CameraDirY, CameraDirZ); //--- ī�޶� �ٶ󺸴� ����
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f); //--- ī�޶� ���� ����

void DrawScene();
void DrawMain();
void DrawFront();
void DrawTop();
void RotateCameraCenterY();
void RotateCameraCenter();
void RotateCamera();
void RotatefrontCamera();
void RotateCrane();
void MoveCraneZ();
void KeyBoard(unsigned char key, int x, int y);
void TimerFunc(int value);

GLfloat LineDots[][3] = {
	{5.0, 0.0, 0.0},
	{-5.0, 0.0, 0.0},
	{0.0, 5.0, 0.0},
	{0.0, 0.0, 0.0},
	{0.0, 0.0, 5.0},
	{0.0, 0.0, -5.0},
};

GLfloat LineColors[][3] = {
	{1.0, 0.0, 0.0},
	{1.0, 0.0, 0.0},
	{0.0, 1.0, 0.0},
	{0.0, 1.0, 0.0},
	{0.0, 0.0, 1.0},
	{0.0, 0.0, 1.0},
};

unsigned int Lineindex[] = {
	0, 1,
	2, 3,
	4, 5
};

GLfloat Dots[][3] = {
	// ����ü
	{-BOXSIZE, BOXSIZE, BOXSIZE},
	{-BOXSIZE, -BOXSIZE, BOXSIZE},
	{BOXSIZE, -BOXSIZE, BOXSIZE},
	{BOXSIZE, BOXSIZE, BOXSIZE},
	{-BOXSIZE, BOXSIZE, -BOXSIZE},
	{-BOXSIZE, -BOXSIZE, -BOXSIZE},
	{BOXSIZE, -BOXSIZE, -BOXSIZE},
	{BOXSIZE, BOXSIZE, -BOXSIZE}
};

unsigned int Shapeindex[] = {
	// ����ü
	0, 1, 2,
	0, 2, 3,
	4, 6, 5,
	4, 7, 6,
	3, 2, 6,
	3, 6, 7,
	4, 5, 1,
	4, 1, 0,
	4, 0, 3,
	4, 3, 7,
	1, 5, 6,
	1, 6, 2
};

void make_vertexShaders()
{
	vertexsource = filetobuf("vertex.glsl");
	vertexShader[0] = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader[0], 1, (const GLchar**)&vertexsource, NULL);
	glCompileShader(vertexShader[0]);

	vertexsource = filetobuf("vertex_crane.glsl");
	vertexShader[1] = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader[1], 1, (const GLchar**)&vertexsource, NULL);
	glCompileShader(vertexShader[1]);
}

void make_fragmentShaders()
{
	fragmentsource = filetobuf("fragment.glsl");
	fragmentShader[0] = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader[0], 1, (const GLchar**)&fragmentsource, NULL);
	glCompileShader(fragmentShader[0]);

	fragmentsource = filetobuf("fragment_floor.glsl");
	fragmentShader[1] = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader[1], 1, (const GLchar**)&fragmentsource, NULL);
	glCompileShader(fragmentShader[1]);

	fragmentsource = filetobuf("fragment_body.glsl");
	fragmentShader[2] = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader[2], 1, (const GLchar**)&fragmentsource, NULL);
	glCompileShader(fragmentShader[2]);

	fragmentsource = filetobuf("fragment_head.glsl");
	fragmentShader[3] = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader[3], 1, (const GLchar**)&fragmentsource, NULL);
	glCompileShader(fragmentShader[3]);

	fragmentsource = filetobuf("fragment_arm.glsl");
	fragmentShader[4] = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader[4], 1, (const GLchar**)&fragmentsource, NULL);
	glCompileShader(fragmentShader[4]);
}

void InitBuffer()
{
	glGenVertexArrays(2, vao);
	glGenBuffers(3, vbo);
	glGenBuffers(3, EBO);

	glBindVertexArray(vao[0]);

	glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(LineDots), LineDots, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[0]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Lineindex), Lineindex, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(LineColors), LineColors, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[1]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Lineindex), Lineindex, GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(1);

	glBindVertexArray(vao[1]);

	glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(Dots), Dots, GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[2]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Shapeindex), Shapeindex, GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), 0);
	glEnableVertexAttribArray(0);
}

void InitShader()
{
	make_vertexShaders();
	make_fragmentShaders();

	s_program[0] = glCreateProgram();

	glAttachShader(s_program[0], vertexShader[0]);
	glAttachShader(s_program[0], fragmentShader[0]);
	glLinkProgram(s_program[0]);

	s_program[1] = glCreateProgram();

	glAttachShader(s_program[1], vertexShader[1]);
	glAttachShader(s_program[1], fragmentShader[1]);
	glLinkProgram(s_program[1]);

	s_program[2] = glCreateProgram();

	glAttachShader(s_program[2], vertexShader[1]);
	glAttachShader(s_program[2], fragmentShader[2]);
	glLinkProgram(s_program[2]);

	s_program[3] = glCreateProgram();

	glAttachShader(s_program[3], vertexShader[1]);
	glAttachShader(s_program[3], fragmentShader[3]);
	glLinkProgram(s_program[3]);

	s_program[4] = glCreateProgram();

	glAttachShader(s_program[4], vertexShader[1]);
	glAttachShader(s_program[4], fragmentShader[4]);
	glLinkProgram(s_program[4]);

	s_program[5] = glCreateProgram();

	glAttachShader(s_program[5], vertexShader[1]);
	glAttachShader(s_program[5], fragmentShader[4]);
	glLinkProgram(s_program[5]);

	glDeleteShader(vertexShader[0]);
	glDeleteShader(vertexShader[1]);
	glDeleteShader(fragmentShader[0]);
	glDeleteShader(fragmentShader[1]);
	glDeleteShader(fragmentShader[2]);
	glDeleteShader(fragmentShader[3]);
}

void DrawScene() //--- glutDisplayFunc()�Լ��� ����� �׸��� �ݹ� �Լ�
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glViewport(0, 0, 900, 900);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);
	DrawMain();
	glDisable(GL_DEPTH_TEST);

	glViewport(1000, 500, 300, 300);
	glEnable(GL_DEPTH_TEST);
	DrawFront();
	glDisable(GL_DEPTH_TEST);

	glViewport(1000, 100, 300, 300);
	glEnable(GL_DEPTH_TEST);
	DrawTop();
	glDisable(GL_DEPTH_TEST);
	glutSwapBuffers();
}


GLvoid Reshape(int w, int h) //--- �ݹ� �Լ�: �ٽ� �׸��� �ݹ� �Լ�
{
	glViewport(0, 0, w, h);
}

char* filetobuf(const char* file)
{
	std::ifstream TextFile;
	int size;
	char* str = NULL;
	TextFile.open(file);

	if (TextFile.is_open())
	{
		TextFile.seekg(0, std::ios::end);
		size = TextFile.tellg();
		str = new char[size];
		for (int i = 0; i < size; ++i)
			str[i] = '\0';
		TextFile.seekg(0, std::ios::beg);
		TextFile.read(str, size);
		TextFile.close();
		return str;
	}
	else
		return NULL;
}

void main(int argc, char** argv)	//---������ ����ϰ� �ݹ��Լ� ����
{
	width = 1400;
	height = 900;

	//---������ �����ϱ�
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glutInitWindowPosition(100, 30);
	glutInitWindowSize(width, height);
	glutCreateWindow("Training19");

	//--- GLEW �ʱ�ȭ�ϱ�
	glewExperimental = GL_TRUE;
	glewInit();
	InitShader();
	InitBuffer();
	glutDisplayFunc(DrawScene);
	glutReshapeFunc(Reshape);
	glutKeyboardFunc(KeyBoard);
	glutTimerFunc(25, TimerFunc, 1);
	glutMainLoop();
}

void KeyBoard(unsigned char key, int x, int y)
{
	switch (key) {
	case '1':
		RotateOnlyFront = !RotateOnlyFront;
		break;
	case '2':
		RotateOnlyTop = !RotateOnlyTop;
		break;
	case 'B':
		if (MoveMinusZ)
			MoveMinusZ = false;
		else
		{
			MoveMinusZ = true;
			MovePlusZ = false;
		}
		break;
	case 'b':
		if (MovePlusZ)
			MovePlusZ = false;
		else
		{
			MovePlusZ = true;
			MoveMinusZ = false;
		}
		break;
	case 'M':
		if (RotateCraneMinus)
			RotateCraneMinus = false;
		else
		{
			RotateCraneMinus = true;
			RotateCranePlus = false;
		}
		break;
	case 'm':
		if (RotateCranePlus)
			RotateCranePlus = false;
		else
		{
			RotateCranePlus = true;
			RotateCraneMinus = false;
		}
		break;
	case 'T':
	case 't':
		RotateArm = !RotateArm;
		break;
	case 'X':
		topCameraDirX -= 0.5f;
		frontCameraDirX -= 0.5f;
		CameraDirX -= 0.5f;
		topcameraX -= 0.5f;
		frontcameraX -= 0.5f;
		cameraX -= 0.5f;
		break;
	case 'x':
		topCameraDirX += 0.5f;
		frontCameraDirX += 0.5f;
		CameraDirX += 0.5f;
		topcameraX += 0.5f;
		frontcameraX += 0.5f;
		cameraX += 0.5f;
		break;
	case 'y':
	case 'Y':
		RotateY = !RotateY;
		break;
	case 'A':
	case 'a':
		RotateA = !RotateA;
		break;
	case 'Z':
		topCameraDirZ -= 0.5f;
		frontCameraDirZ -= 0.5f;
		CameraDirZ -= 0.5f;
		topcameraZ -= 0.5f;
		frontcameraZ -= 0.5f;
		cameraZ -= 0.5f;
		break;
	case 'z':
		topCameraDirZ += 0.5f;
		frontCameraDirZ += 0.5f;
		CameraDirZ += 0.5f;
		topcameraZ += 0.5f;
		frontcameraZ += 0.5f;
		cameraZ += 0.5f;
		break;
	case 'R':
	case 'r':
		RotateR = !RotateR;
		break;
	case 'S':
	case 's':
		RotateA = false, RotateR = false, RotateY = false, MovePlusZ = false, MoveMinusZ = false, RotateCranePlus = false, RotateCraneMinus = false, RotateArm = false;
		break;
	case 'C':
	case 'c':
		RotateA = false, RotateR = false, RotateY = false, MovePlusZ = false, MoveMinusZ = false, RotateCranePlus = false, RotateCraneMinus = false, RotateArm = false, ArmPlus = true;
		RotateCenterY = 0.0, cameraX = 0.0, cameraY = 3.0, cameraZ = 4.0, frontcameraX = 0.0, frontcameraZ = 1.0, topcameraX = 0.0, topcameraZ = 0.0, cameraR = 0.0, craneZ = 0.0, cranebodyR = 0.0, armR = 0.0, RotateCenter = 0.0;
		CameraDirX = 0.0, CameraDirY = 0.0, CameraDirZ = 0.0;
		frontCameraDirX = 0.0, frontCameraDirZ = 0.0;
		topCameraDirX = 0.0, topCameraDirZ = 0.0;
		break;
	case 'Q':
	case 'q':
		glutLeaveMainLoop();
		break;
	}
	glutPostRedisplay();
}

void TimerFunc(int value)
{
	if (RotateR)
		RotateCameraCenterY();
	if (RotateA)
		RotateCameraCenter();
	if (RotateY)
	{
		RotatefrontCamera();
		cameraR = (GLfloat)((int)(cameraR + 1.0) % 360);
		topR = (GLfloat)((int)(topR + 1.0) % 360);
	}
	
	if(RotateOnlyFront)
		RotatefrontCamera();

	if(RotateOnlyTop)
		topR = (GLfloat)((int)(topR + 1.0) % 360);


	if (MoveMinusZ || MovePlusZ)
		MoveCraneZ();
	if (RotateCranePlus || RotateCraneMinus)
		RotateCrane();
	if (RotateArm)
	{
		if (ArmPlus)
		{
			armR = armR + 1.0;
			if (armR >= 90.0)
				ArmPlus = false;
		}
		else
		{
			armR = armR - 1.0;
			if (armR <= -90.0)
				ArmPlus = true;
		}
	}
	glutTimerFunc(25, TimerFunc, 1);
	glutPostRedisplay();
}

void RotateCameraCenterY()
{
	GLfloat tmpX = cameraZ * glm::sin(glm::radians(1.0)) + cameraX * glm::cos(glm::radians(1.0));
	GLfloat tmpZ = cameraZ * glm::cos(glm::radians(1.0)) - cameraX * glm::sin(glm::radians(1.0));

	cameraX = tmpX;
	cameraZ = tmpZ;
}

void RotatefrontCamera()
{
	GLfloat tmpX = frontcameraZ * glm::sin(glm::radians(1.0)) + frontcameraX * glm::cos(glm::radians(1.0));
	GLfloat tmpZ = frontcameraZ * glm::cos(glm::radians(1.0)) - frontcameraX * glm::sin(glm::radians(1.0));

	frontcameraX = tmpX;
	frontcameraZ = tmpZ;
}

void RotateCameraCenter()
{
	GLfloat tmpY = cameraY * glm::cos(glm::radians(1.0)) - cameraZ * glm::sin(glm::radians(1.0));
	GLfloat tmpZ = cameraY * glm::sin(glm::radians(1.0)) + cameraZ * glm::cos(glm::radians(1.0));

	cameraY = tmpY;
	cameraZ = tmpZ;
}

void RotateCamera()
{
	GLfloat tmpDirX = CameraDirX - cameraX;
	GLfloat tmpDirZ = CameraDirZ - cameraZ;
	GLfloat tmpX = tmpDirZ * glm::sin(glm::radians(cameraR)) + tmpDirX * glm::cos(glm::radians(cameraR));
	GLfloat tmpZ = tmpDirZ * glm::cos(glm::radians(cameraR)) - tmpDirX * glm::sin(glm::radians(cameraR));

	cameraDirection = glm::vec3(tmpX + cameraX, 0.0f, tmpZ + cameraZ);
}

void MoveCraneZ()
{
	if (MovePlusZ)
	{
		if (craneZ < 8.5f)
			craneZ += 0.1f;
	}
	else
	{
		if (craneZ > -8.5f)
			craneZ -= 0.1f;
	}
}

void RotateCrane()
{
	if (RotateCraneMinus)
	{
		cranebodyR = cranebodyR - 1.0;
		if (cranebodyR < 0.0)
			cranebodyR += 360.0;
	}
	else
	{
		cranebodyR = (GLfloat)((int)(cranebodyR + 1.0) % 360);
	}
}

void DrawMain()
{
	glm::mat4 transformMatrix[4] = { glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f) };
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 projection = glm::mat4(1.0f);

	unsigned int projectionLocation;
	unsigned int modelLocation;
	unsigned int viewLocation;



	projection = glm::perspective(glm::radians(130.0f), (float)width / (float)height, 0.1f, 50.0f);
	projection = glm::translate(projection, glm::vec3(0.0, 0.0, -0.5));

	cameraPos = glm::vec3(cameraX, cameraY, cameraZ);
	cameraDirection = glm::vec3(CameraDirX, CameraDirY, CameraDirZ);
	RotateCamera();
	view = glm::lookAt(cameraPos, cameraDirection, cameraUp);

	// ��ǥ��
	glUseProgram(s_program[0]);
	glBindVertexArray(vao[0]);

	viewLocation = glGetUniformLocation(s_program[0], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[0], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[0], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_LINES, 6, GL_UNSIGNED_INT, 0);

	// �ٴ�
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, -0.05, -BOXSIZE));
	transformMatrix[0] = glm::rotate(transformMatrix[0], (GLfloat)glm::radians(-90.0), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(20.0, 20.0, 1.0));
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, 0.0, -BOXSIZE));


	// �ٴڱ��
	glUseProgram(s_program[1]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[1], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[1], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[1], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

	// ��ü
	transformMatrix[0] = glm::mat4(1.0f);
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, BOXSIZE, craneZ));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(2.0, 1.0, 2.0));

	// ũ���� ��ü
	glUseProgram(s_program[2]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[2], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[2], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[2], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// �Ӹ�
	transformMatrix[1] = glm::translate(transformMatrix[1], glm::vec3(0.0, 2.0 * BOXSIZE, craneZ));
	transformMatrix[1] = glm::rotate(transformMatrix[1], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[1] = glm::scale(transformMatrix[1], glm::vec3(1.25, 1.0, 1.25));

	// ũ���� �Ӹ�
	glUseProgram(s_program[3]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[3], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[3], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[3], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[1]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ���� ��
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(-0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[2] = glm::scale(transformMatrix[2], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ���� ��
	glUseProgram(s_program[4]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[4], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[4], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[4], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[2]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ������ ��
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(-armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[3] = glm::scale(transformMatrix[3], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ������ ��
	glUseProgram(s_program[5]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[5], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[5], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[5], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[3]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
}

void DrawFront()
{
	glm::mat4 transformMatrix[4] = { glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f) };
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 projection = glm::mat4(1.0f);

	unsigned int projectionLocation;
	unsigned int modelLocation;
	unsigned int viewLocation;

	projection = glm::ortho(-10.0, 10.0, -2.0, 18.0, -15.0, 15.0);

	frontcameraPos = glm::vec3(frontcameraX, 0.0, frontcameraZ);
	frontcameraDirection = glm::vec3(frontCameraDirX, 0.0, frontCameraDirZ);
	view = glm::lookAt(frontcameraPos, frontcameraDirection, frontcameraUp);

	// ��ǥ��
	glUseProgram(s_program[0]);
	glBindVertexArray(vao[0]);

	viewLocation = glGetUniformLocation(s_program[0], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[0], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[0], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_LINES, 6, GL_UNSIGNED_INT, 0);

	// �ٴ�
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, -0.05, -BOXSIZE));
	transformMatrix[0] = glm::rotate(transformMatrix[0], (GLfloat)glm::radians(-90.0), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(20.0, 20.0, 1.0));
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, 0.0, -BOXSIZE));


	// �ٴڱ��
	glUseProgram(s_program[1]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[1], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[1], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[1], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

	// ��ü
	transformMatrix[0] = glm::mat4(1.0f);
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, BOXSIZE, craneZ));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(2.0, 1.0, 2.0));

	// ũ���� ��ü
	glUseProgram(s_program[2]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[2], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[2], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[2], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// �Ӹ�
	transformMatrix[1] = glm::translate(transformMatrix[1], glm::vec3(0.0, 2.0 * BOXSIZE, craneZ));
	transformMatrix[1] = glm::rotate(transformMatrix[1], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[1] = glm::scale(transformMatrix[1], glm::vec3(1.25, 1.0, 1.25));

	// ũ���� �Ӹ�
	glUseProgram(s_program[3]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[3], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[3], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[3], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[1]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ���� ��
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(-0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[2] = glm::scale(transformMatrix[2], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ���� ��
	glUseProgram(s_program[4]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[4], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[4], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[4], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[2]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ������ ��
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(-armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[3] = glm::scale(transformMatrix[3], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ������ ��
	glUseProgram(s_program[5]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[5], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[5], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[5], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[3]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
}

void DrawTop()
{
	glm::mat4 transformMatrix[4] = { glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f), glm::mat4(1.0f) };
	glm::mat4 view = glm::mat4(1.0f);
	glm::mat4 projection = glm::mat4(1.0f);

	unsigned int projectionLocation;
	unsigned int modelLocation;
	unsigned int viewLocation;

	projection = glm::ortho(-10.0, 10.0, -10.0, 10.0, -5.0, 5.0);
	glm::vec3 topcameraPos = glm::vec3(topcameraX, 2.0, topcameraZ);
	glm::vec3 topcameraDirection = glm::vec3(topCameraDirX, 0.0, topCameraDirZ);
	topcameraUp = glm::vec3(1.0 * glm::sin(glm::radians(topR)), 0.0f, 1.0 * glm::cos(glm::radians(topR)));
	view = glm::lookAt(topcameraPos, topcameraDirection, topcameraUp);

	// ��ǥ��
	glUseProgram(s_program[0]);
	glBindVertexArray(vao[0]);

	viewLocation = glGetUniformLocation(s_program[0], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[0], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[0], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_LINES, 6, GL_UNSIGNED_INT, 0);

	// �ٴ�
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, -0.05, -BOXSIZE));
	transformMatrix[0] = glm::rotate(transformMatrix[0], (GLfloat)glm::radians(-90.0), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(20.0, 20.0, 1.0));
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, 0.0, -BOXSIZE));


	// �ٴڱ��
	glUseProgram(s_program[1]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[1], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[1], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[1], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

	// ��ü
	transformMatrix[0] = glm::mat4(1.0f);
	transformMatrix[0] = glm::translate(transformMatrix[0], glm::vec3(0.0, BOXSIZE, craneZ));
	transformMatrix[0] = glm::scale(transformMatrix[0], glm::vec3(2.0, 1.0, 2.0));

	// ũ���� ��ü
	glUseProgram(s_program[2]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[2], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[2], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[2], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[0]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// �Ӹ�
	transformMatrix[1] = glm::translate(transformMatrix[1], glm::vec3(0.0, 2.0 * BOXSIZE, craneZ));
	transformMatrix[1] = glm::rotate(transformMatrix[1], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[1] = glm::scale(transformMatrix[1], glm::vec3(1.25, 1.0, 1.25));

	// ũ���� �Ӹ�
	glUseProgram(s_program[3]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[3], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[3], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[3], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[1]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ���� ��
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(-0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[2] = glm::rotate(transformMatrix[2], (GLfloat)glm::radians(armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[2] = glm::translate(transformMatrix[2], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[2] = glm::scale(transformMatrix[2], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ���� ��
	glUseProgram(s_program[4]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[4], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[4], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[4], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[2]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);

	// ������ ��
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0.5 * BOXSIZE, 3.0 * BOXSIZE, craneZ));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(cranebodyR), glm::vec3(0.0, 1.0, 0.0));
	transformMatrix[3] = glm::rotate(transformMatrix[3], (GLfloat)glm::radians(-armR), glm::vec3(1.0, 0.0, 0.0));
	transformMatrix[3] = glm::translate(transformMatrix[3], glm::vec3(0, 1.5 * BOXSIZE, 0));
	transformMatrix[3] = glm::scale(transformMatrix[3], glm::vec3(0.25, 1.5, 0.25));

	// ũ���� ������ ��
	glUseProgram(s_program[5]);
	glBindVertexArray(vao[1]);

	viewLocation = glGetUniformLocation(s_program[5], "viewTransform");
	glUniformMatrix4fv(viewLocation, 1, GL_FALSE, &view[0][0]);

	projectionLocation = glGetUniformLocation(s_program[5], "projectionTransform");
	glUniformMatrix4fv(projectionLocation, 1, GL_FALSE, &projection[0][0]);

	modelLocation = glGetUniformLocation(s_program[5], "modelTransform");
	glUniformMatrix4fv(modelLocation, 1, GL_FALSE, glm::value_ptr(transformMatrix[3]));

	glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
}